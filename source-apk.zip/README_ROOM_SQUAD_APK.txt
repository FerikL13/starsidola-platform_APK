STARS IDOLA APK v1.3.0 — Game Star Arena dibungkus di dalam APK (Room Squad)
============================================================================
Yang berubah (hanya app/src/main/java/com/starsidola/global/MainActivity.java + versi di app/build.gradle):

1. Jembatan baru StarsIdolaNative (dipakai web v7.3.1+):
   - openGame(url, judul): membuka game di WebView ANAK di dalam APK (lapisan layar penuh di atas WebView utama).
     WebView utama tetap hidup, jadi suara Room Squad tidak putus. http/https tetap di dalam; skema lain dibuka lewat aplikasi terkait.
   - closeGame(), roomState(joined, muted, talking, count), gameReply(json), roomBridgeVersion().
2. Bubble NATIVE melayang di atas game (hanya tampil bila sedang di Room Squad):
   ketuk 1x = mute/unmute · ketuk 2x = tutup game + kembali ke modul Squad · tahan lama = geser (menempel ke tepi, posisi diingat).
3. Tombol Back HP: di dalam game = mundur halaman game, lalu tutup game. Tombol ✕ di bar atas = tutup game. ↗ = buka di browser luar.
4. Pengganti window.opener untuk game (toko in-game): pesan "stars_*" diteruskan ke halaman utama dan balasannya dikembalikan ke game.
5. Game pihak ketiga TIDAK boleh memakai mikrofon (izin ditolak); mikrofon hanya milik Room Squad.

Tidak diubah: aturan star_arena_url di strings.xml tetap membuka link berawalan itu di browser luar untuk link biasa
(bukan untuk game yang dibuka lewat jembatan openGame).

Build: seperti biasa lewat GitHub Actions (upload zip ini ke repo atau timpa isi repo, jalankan "Build STARS IDOLA Global APK").
Setelah APK terpasang, web v7.3.1+ otomatis memakai jalur native; APK lama tetap jalan dengan jalur cadangan (iframe).

Yang belum termasuk (tahap lanjut): suara tetap hidup saat aplikasi di latar / layar terkunci (butuh Foreground Service mikrofon).
