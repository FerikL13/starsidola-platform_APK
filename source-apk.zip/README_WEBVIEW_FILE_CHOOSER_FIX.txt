STARS IDOLA APK - WebView File Chooser Fix

Perbaikan ini untuk fitur Music HP dari index.html.

Masalah di source lama:
- MainActivity memakai WebChromeClient kosong.
- Tidak ada onShowFileChooser, jadi input type=file dari HTML tidak membuka picker file di APK.
- setAllowFileAccess(false) dan setAllowContentAccess(false), sehingga akses file/content HP diblokir.

Perbaikan:
- Tambah StarsWebChromeClient dengan onShowFileChooser.
- Mendukung pilih audio banyak file / multiple.
- Aktifkan allowFileAccess dan allowContentAccess.
- Manifest ditambah READ_MEDIA_AUDIO, READ_EXTERNAL_STORAGE maxSdk 32, dan hardwareAccelerated true.

Catatan:
- ZIP ini source APK, bukan APK hasil build.
- Upload ke GitHub lalu jalankan workflow Build APK untuk menghasilkan app-debug.apk baru.
- Jangan pakai app-debug.apk lama dari ZIP sebelumnya karena belum memiliki fix ini.
