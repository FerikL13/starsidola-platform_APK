STARS IDOLA GLOBAL APK BUILD SOURCE
===================================

Fungsi:
- Project ini adalah wadah APK Android WebView untuk STARS IDOLA Global.
- APK hanya membuka Global platform.
- Official/Office tidak dimasukkan.
- STAR ARENA diarahkan ke jalur web terpisah.
- Fitur download APK di platform bisa dibuka lewat browser/download manager.

File penting:
- app/src/main/res/values/strings.xml
  Ganti global_url dengan link Global final.
  Ganti star_arena_url dengan link STAR ARENA final.

Default sekarang:
- global_url: https://platform.starsidola.workers.dev
- star_arena_url: https://star-arena.starsidola.workers.dev

Build lewat GitHub:
1. Buat repo baru khusus APK source.
2. Upload semua isi folder ini ke repo.
3. Buka tab Actions.
4. Jalankan workflow "Build STARS IDOLA Global APK".
5. Download artifact: stars-idola-global-debug-apk.

Build lewat Android Studio:
1. Buka folder project ini.
2. Tunggu Gradle sync.
3. Build > Build APK(s).
4. APK ada di app/build/outputs/apk/debug/app-debug.apk.

Catatan:
- Ini debug APK untuk test awal.
- Untuk rilis resmi nanti perlu signed release APK/AAB.
- Update isi platform cukup update Global Web/deploy.
- APK baru hanya diperlukan kalau setting Android berubah.
