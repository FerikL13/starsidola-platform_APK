package com.starsidola.global;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;

import androidx.core.app.NotificationCompat;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

/** Menerima token FCM baru dan menampilkan push saat aplikasi sedang terbuka (foreground). */
public class StarsFirebaseService extends FirebaseMessagingService {
    static final String PREFS = "stars_push";
    static final String KEY_TOKEN = "token";
    static final String CHANNEL_ID = "stars_default";

    static void ensureChannel(Context ctx) {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null || nm.getNotificationChannel(CHANNEL_ID) != null) return;
        NotificationChannel ch = new NotificationChannel(CHANNEL_ID, "Notifikasi STARS IDOLA", NotificationManager.IMPORTANCE_HIGH);
        ch.setDescription("Transfer, pesan, reward, dan info akun");
        nm.createNotificationChannel(ch);
    }

    @Override
    public void onNewToken(String token) {
        SharedPreferences sp = getSharedPreferences(PREFS, MODE_PRIVATE);
        sp.edit().putString(KEY_TOKEN, token).apply();
    }

    @Override
    public void onMessageReceived(RemoteMessage message) {
        // Saat aplikasi di background, sistem menampilkan bagian "notification" sendiri.
        // Fungsi ini hanya dipanggil untuk foreground/data-only, jadi kita tampilkan manual.
        RemoteMessage.Notification n = message.getNotification();
        if (n == null) return;
        ensureChannel(this);
        Intent launch = getPackageManager().getLaunchIntentForPackage(getPackageName());
        if (launch == null) return;
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
        PendingIntent pi = PendingIntent.getActivity(this, 0, launch, flags);
        Notification notif = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_stat_stars)
                .setContentTitle(n.getTitle() != null ? n.getTitle() : "STARS IDOLA")
                .setContentText(n.getBody())
                .setStyle(new NotificationCompat.BigTextStyle().bigText(n.getBody()))
                .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setContentIntent(pi)
                .build();
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) nm.notify((int) (System.currentTimeMillis() & 0x7fffffff), notif);
    }
}
