package com.starsidola.global;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.DownloadManager;
import android.content.ClipData;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.media.AudioManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int FILE_CHOOSER_REQUEST_CODE = 1001;
    private static final int MEDIA_PERMISSION_REQUEST_CODE = 1002;
    private static final int MIC_PERMISSION_REQUEST_CODE = 1003;
    private static final int STORAGE_WRITE_REQUEST_CODE = 1004;
    private PermissionRequest pendingMicRequest;

    private WebView webView;
    private String globalUrl;
    private String starArenaUrl;
    private ValueCallback<Uri[]> filePathCallback;
    private WebChromeClient.FileChooserParams pendingFileChooserParams;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        globalUrl = getString(R.string.global_url);
        starArenaUrl = getString(R.string.star_arena_url);

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(5, 7, 18));
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setMediaPlaybackRequiresUserGesture(false);

        // Wajib untuk input type="file" di WebView: dipakai untuk musik/audio DAN untuk
        // bukti gambar top up (Top Up Manual). Jangan asumsikan cuma audio.
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);

        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);

        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);

        webView.setWebChromeClient(new StarsWebChromeClient());
        webView.setWebViewClient(new StarsWebViewClient());
        webView.setDownloadListener(new StarsDownloadListener());
        // Jembatan simpan media chat ke folder perangkat (galeri "STARS IDOLA").
        webView.addJavascriptInterface(new NativeBridge(), "StarsIdolaNative");
        // Android 6-9 butuh izin tulis eksternal untuk menyimpan ke folder publik.
        if (Build.VERSION.SDK_INT < 29 && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, STORAGE_WRITE_REQUEST_CODE);
        }

        if (isOnline()) {
            webView.loadUrl(globalUrl);
        } else {
            webView.loadUrl("file:///android_asset/offline.html");
        }
    }

    /** Kembalikan mode audio ke NORMAL kalau tersangkut di mode lain, agar mic bisa dibuka WebView. */
    private void resetAudioModeForMic() {
        try {
            AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
            if (am != null && am.getMode() != AudioManager.MODE_NORMAL && am.getMode() != AudioManager.MODE_IN_CALL
                    && am.getMode() != AudioManager.MODE_IN_COMMUNICATION) {
                am.setMode(AudioManager.MODE_NORMAL);
            }
        } catch (Exception ignored) {}
    }

    /** Izin media yang relevan untuk versi Android yang sedang jalan (API 33+ pakai izin granular). */
    private String[] mediaPermissionsNeeded() {
        if (Build.VERSION.SDK_INT >= 33) {
            return new String[]{
                Manifest.permission.READ_MEDIA_IMAGES,
                Manifest.permission.READ_MEDIA_VIDEO,
                Manifest.permission.READ_MEDIA_AUDIO
            };
        }
        return new String[]{Manifest.permission.READ_EXTERNAL_STORAGE};
    }

    private boolean hasMediaPermission() {
        for (String permission : mediaPermissionsNeeded()) {
            if (checkSelfPermission(permission) != PackageManager.PERMISSION_GRANTED) {
                return false;
            }
        }
        return true;
    }

    private class StarsWebChromeClient extends WebChromeClient {
        @Override
        public void onPermissionRequest(final PermissionRequest request) {
            runOnUiThread(() -> {
                boolean needsMic = false;
                for (String r : request.getResources()) {
                    if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r)) needsMic = true;
                }
                if (!needsMic) {
                    request.deny();
                    return;
                }
                if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    // Batalkan request lama yang masih menggantung supaya tidak bocor.
                    if (pendingMicRequest != null) {
                        try { pendingMicRequest.deny(); } catch (Exception ignored) {}
                    }
                    pendingMicRequest = request;
                    requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, MIC_PERMISSION_REQUEST_CODE);
                } else {
                    // Pastikan tidak ada mode audio sisa (mis. mode telepon) yang menahan sumber mic.
                    resetAudioModeForMic();
                    request.grant(new String[]{PermissionRequest.RESOURCE_AUDIO_CAPTURE});
                }
            });
        }

        @Override
        public void onPermissionRequestCanceled(PermissionRequest request) {
            if (pendingMicRequest == request) pendingMicRequest = null;
        }

        @Override
        public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> callback, FileChooserParams fileChooserParams) {
            if (filePathCallback != null) {
                filePathCallback.onReceiveValue(null);
            }
            filePathCallback = callback;

            if (!hasMediaPermission()) {
                // Tunda buka file chooser sampai izin dikasih user; hasilnya dilanjutkan di
                // onRequestPermissionsResult supaya tidak diam-diam gagal di Android 13+.
                pendingFileChooserParams = fileChooserParams;
                requestPermissions(mediaPermissionsNeeded(), MEDIA_PERMISSION_REQUEST_CODE);
                return true;
            }

            return launchFileChooser(fileChooserParams);
        }
    }

    private boolean launchFileChooser(WebChromeClient.FileChooserParams fileChooserParams) {
        Intent intent;
        try {
            intent = fileChooserParams.createIntent();
        } catch (Exception e) {
            intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("*/*");
            intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        }

        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        intent.addFlags(Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);

        try {
            startActivityForResult(intent, FILE_CHOOSER_REQUEST_CODE);
            return true;
        } catch (Exception e) {
            if (filePathCallback != null) {
                filePathCallback.onReceiveValue(null);
            }
            filePathCallback = null;
            Toast.makeText(MainActivity.this, "Tidak bisa membuka pemilih file di HP ini", Toast.LENGTH_SHORT).show();
            return false;
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == MIC_PERMISSION_REQUEST_CODE) {
            PermissionRequest req = pendingMicRequest;
            pendingMicRequest = null;
            if (req != null) {
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    resetAudioModeForMic();
                    req.grant(new String[]{PermissionRequest.RESOURCE_AUDIO_CAPTURE});
                } else {
                    req.deny();
                    Toast.makeText(this, "Izin mikrofon ditolak, voice note tidak bisa direkam.", Toast.LENGTH_SHORT).show();
                }
            }
            return;
        }
        if (requestCode != MEDIA_PERMISSION_REQUEST_CODE) return;

        WebChromeClient.FileChooserParams params = pendingFileChooserParams;
        pendingFileChooserParams = null;

        boolean granted = grantResults.length > 0;
        for (int result : grantResults) {
            if (result != PackageManager.PERMISSION_GRANTED) { granted = false; break; }
        }

        if (granted && params != null) {
            launchFileChooser(params);
        } else {
            if (filePathCallback != null) {
                filePathCallback.onReceiveValue(null);
                filePathCallback = null;
            }
            Toast.makeText(this, "Izin akses file ditolak, tidak bisa pilih file.", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode != FILE_CHOOSER_REQUEST_CODE || filePathCallback == null) {
            return;
        }

        Uri[] results = null;
        if (resultCode == RESULT_OK && data != null) {
            ClipData clipData = data.getClipData();
            if (clipData != null && clipData.getItemCount() > 0) {
                int count = clipData.getItemCount();
                results = new Uri[count];
                for (int i = 0; i < count; i++) {
                    results[i] = clipData.getItemAt(i).getUri();
                }
            } else if (data.getData() != null) {
                results = new Uri[]{data.getData()};
            } else {
                results = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
            }
        }

        filePathCallback.onReceiveValue(results);
        filePathCallback = null;
    }

    private class StarsWebViewClient extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, android.webkit.WebResourceRequest request) {
            String url = request.getUrl().toString();
            return handleUrl(view, url);
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            return handleUrl(view, url);
        }

        private boolean handleUrl(WebView view, String url) {
            if (url == null) return false;

            // STAR ARENA diarahkan keluar APK ke jalur web khusus.
            if (url.startsWith(starArenaUrl) || url.contains("star-arena")) {
                openExternal(url);
                return true;
            }

            // Link download APK atau file eksternal dibuka lewat browser/download manager.
            if (url.endsWith(".apk") || url.contains("/download") || url.contains("apk")) {
                openExternal(url);
                return true;
            }

            // Link tel/mail/whatsapp/telegram dibuka lewat aplikasi terkait.
            if (
                url.startsWith("tel:") ||
                url.startsWith("mailto:") ||
                url.startsWith("whatsapp:") ||
                url.startsWith("tg:") ||
                url.startsWith("https://t.me/")
            ) {
                openExternal(url);
                return true;
            }

            return false;
        }
    }

    private class StarsDownloadListener implements DownloadListener {
        @Override
        public void onDownloadStart(String url, String userAgent, String contentDisposition, String mimetype, long contentLength) {
            try {
                DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
                request.setMimeType(mimetype);
                request.addRequestHeader("User-Agent", userAgent);
                request.setTitle(URLUtil.guessFileName(url, contentDisposition, mimetype));
                request.setDescription("Mengunduh file STARS IDOLA");
                request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, URLUtil.guessFileName(url, contentDisposition, mimetype));

                DownloadManager dm = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
                if (dm != null) {
                    dm.enqueue(request);
                    Toast.makeText(MainActivity.this, "Download dimulai", Toast.LENGTH_SHORT).show();
                } else {
                    openExternal(url);
                }
            } catch (Exception e) {
                openExternal(url);
            }
        }
    }


    /** Dipanggil dari chat-media.js: simpan media yang DITERIMA ke folder perangkat (Pictures/Movies/Music -> "STARS IDOLA"). */
    private class NativeBridge {
        /** Diagnosa mic untuk JS: "ok" | "no_permission" | "muted" | "in_call". */
        @JavascriptInterface
        public String micStatus() {
            try {
                if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return "no_permission";
                AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
                if (am != null) {
                    if (am.isMicrophoneMute()) return "muted";
                    int m = am.getMode();
                    if (m == AudioManager.MODE_IN_CALL || m == AudioManager.MODE_IN_COMMUNICATION) return "in_call";
                }
                return "ok";
            } catch (Exception e) {
                return "ok";
            }
        }

        @JavascriptInterface
        public boolean saveMedia(String base64, String mime, String kind, String fileName) {
            try {
                byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
                boolean image = "image".equals(kind), video = "video".equals(kind);
                String dirType = image ? Environment.DIRECTORY_PICTURES : (video ? Environment.DIRECTORY_MOVIES : Environment.DIRECTORY_MUSIC);
                if (Build.VERSION.SDK_INT >= 29) {
                    ContentValues v = new ContentValues();
                    v.put(MediaStore.MediaColumns.DISPLAY_NAME, fileName);
                    v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
                    v.put(MediaStore.MediaColumns.RELATIVE_PATH, dirType + "/STARS IDOLA");
                    Uri collection = image ? MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                            : (video ? MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                            : MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY));
                    Uri uri = getContentResolver().insert(collection, v);
                    if (uri == null) return false;
                    try (OutputStream os = getContentResolver().openOutputStream(uri)) {
                        if (os == null) return false;
                        os.write(bytes);
                    }
                    return true;
                }
                if (checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) return false;
                File dir = new File(Environment.getExternalStoragePublicDirectory(dirType), "STARS IDOLA");
                if (!dir.exists() && !dir.mkdirs()) return false;
                File f = new File(dir, fileName);
                try (FileOutputStream fos = new FileOutputStream(f)) { fos.write(bytes); }
                MediaScannerConnection.scanFile(MainActivity.this, new String[]{f.getAbsolutePath()}, new String[]{mime}, null);
                return true;
            } catch (Exception e) {
                return false;
            }
        }
    }

    private void openExternal(String url) {
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this, "Tidak bisa membuka link", Toast.LENGTH_SHORT).show();
        }
    }

    private boolean isOnline() {
        try {
            ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo info = cm != null ? cm.getActiveNetworkInfo() : null;
            return info != null && info.isConnected();
        } catch (Exception e) {
            return true;
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
