package com.starsidola.global;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.DownloadManager;
import android.content.ClipData;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.media.AudioManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.Settings;
import androidx.core.app.NotificationManagerCompat;
import com.google.firebase.messaging.FirebaseMessaging;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int FILE_CHOOSER_REQUEST_CODE = 1001;
    private static final int MEDIA_PERMISSION_REQUEST_CODE = 1002;
    private static final int MIC_PERMISSION_REQUEST_CODE = 1003;
    private static final int STORAGE_WRITE_REQUEST_CODE = 1004;
    private static final int NOTIF_PERMISSION_REQUEST_CODE = 1005;
    private PermissionRequest pendingMicRequest;

    private WebView webView;
    // ===== Room Squad: game Star Arena dibuka DI DALAM APK (WebView anak) + bubble native =====
    private FrameLayout rootLayout;
    private FrameLayout gameLayer;
    private WebView gameWebView;
    private TextView gameTitleView;
    private String gameCurrentUrl = "";
    private FrameLayout bubbleView;
    private TextView bubbleIcon;
    private TextView bubbleBadge;
    private GradientDrawable bubbleBg;
    private boolean roomJoined, roomMuted, roomTalking;
    private int roomCount;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private Runnable bubbleLongPress, bubblePendingSingle;
    private boolean bubbleDragging, bubbleMoved;
    private float bubbleDownX, bubbleDownY, bubbleStartX, bubbleStartY;
    private long bubbleLastTap;
    private static final String BUBBLE_PREFS = "stars_room_bubble";
    private String globalUrl;
    private String starArenaUrl;
    private ValueCallback<Uri[]> filePathCallback;
    private WebChromeClient.FileChooserParams pendingFileChooserParams;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        globalUrl = getString(R.string.global_url);
        starArenaUrl = getString(R.string.star_arena_url);

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(5, 7, 18));
        rootLayout = new FrameLayout(this);
        rootLayout.setBackgroundColor(Color.rgb(5, 7, 18));
        rootLayout.addView(webView, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(rootLayout);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setMediaPlaybackRequiresUserGesture(false);

        // Wajib untuk input type="file" di WebView: dipakai untuk musik/audio DAN untuk
        // bukti gambar top up (Top Up Manual). Jangan asumsikan cuma audio.
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);

        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);

        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);

        webView.setWebChromeClient(new StarsWebChromeClient());
        webView.setWebViewClient(new StarsWebViewClient());
        webView.setDownloadListener(new StarsDownloadListener());
        // Jembatan simpan media chat ke folder perangkat (galeri "STARS IDOLA").
        webView.addJavascriptInterface(new NativeBridge(), "StarsIdolaNative");
        // Android 6-9 butuh izin tulis eksternal untuk menyimpan ke folder publik.
        if (Build.VERSION.SDK_INT < 29 && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, STORAGE_WRITE_REQUEST_CODE);
        }

        // Push (FCM): siapkan channel dan ambil token perangkat; web mengambilnya lewat StarsIdolaNative.getPushToken().
        StarsFirebaseService.ensureChannel(this);
        try {
            FirebaseMessaging.getInstance().getToken().addOnSuccessListener(t -> {
                if (t != null && !t.isEmpty()) {
                    getSharedPreferences(StarsFirebaseService.PREFS, MODE_PRIVATE).edit().putString(StarsFirebaseService.KEY_TOKEN, t).apply();
                }
            });
        } catch (Exception ignored) {}

        if (isOnline()) {
            webView.loadUrl(globalUrl);
        } else {
            webView.loadUrl("file:///android_asset/offline.html");
        }
    }

    /** Kembalikan mode audio ke NORMAL kalau tersangkut di mode lain, agar mic bisa dibuka WebView. */
    private void resetAudioModeForMic() {
        try {
            AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
            if (am != null && am.getMode() != AudioManager.MODE_NORMAL && am.getMode() != AudioManager.MODE_IN_CALL
                    && am.getMode() != AudioManager.MODE_IN_COMMUNICATION) {
                am.setMode(AudioManager.MODE_NORMAL);
            }
        } catch (Exception ignored) {}
    }

    /** Izin media yang relevan untuk versi Android yang sedang jalan (API 33+ pakai izin granular). */
    private String[] mediaPermissionsNeeded() {
        if (Build.VERSION.SDK_INT >= 33) {
            return new String[]{
                Manifest.permission.READ_MEDIA_IMAGES,
                Manifest.permission.READ_MEDIA_VIDEO,
                Manifest.permission.READ_MEDIA_AUDIO
            };
        }
        return new String[]{Manifest.permission.READ_EXTERNAL_STORAGE};
    }

    private boolean hasMediaPermission() {
        for (String permission : mediaPermissionsNeeded()) {
            if (checkSelfPermission(permission) != PackageManager.PERMISSION_GRANTED) {
                return false;
            }
        }
        return true;
    }

    private class StarsWebChromeClient extends WebChromeClient {
        @Override
        public void onPermissionRequest(final PermissionRequest request) {
            runOnUiThread(() -> {
                boolean needsMic = false;
                for (String r : request.getResources()) {
                    if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r)) needsMic = true;
                }
                if (!needsMic) {
                    request.deny();
                    return;
                }
                if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    // Batalkan request lama yang masih menggantung supaya tidak bocor.
                    if (pendingMicRequest != null) {
                        try { pendingMicRequest.deny(); } catch (Exception ignored) {}
                    }
                    pendingMicRequest = request;
                    requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, MIC_PERMISSION_REQUEST_CODE);
                } else {
                    // Pastikan tidak ada mode audio sisa (mis. mode telepon) yang menahan sumber mic.
                    resetAudioModeForMic();
                    request.grant(new String[]{PermissionRequest.RESOURCE_AUDIO_CAPTURE});
                }
            });
        }

        @Override
        public void onPermissionRequestCanceled(PermissionRequest request) {
            if (pendingMicRequest == request) pendingMicRequest = null;
        }

        @Override
        public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> callback, FileChooserParams fileChooserParams) {
            if (filePathCallback != null) {
                filePathCallback.onReceiveValue(null);
            }
            filePathCallback = callback;

            if (!hasMediaPermission()) {
                // Tunda buka file chooser sampai izin dikasih user; hasilnya dilanjutkan di
                // onRequestPermissionsResult supaya tidak diam-diam gagal di Android 13+.
                pendingFileChooserParams = fileChooserParams;
                requestPermissions(mediaPermissionsNeeded(), MEDIA_PERMISSION_REQUEST_CODE);
                return true;
            }

            return launchFileChooser(fileChooserParams);
        }
    }

    private boolean launchFileChooser(WebChromeClient.FileChooserParams fileChooserParams) {
        Intent intent;
        try {
            intent = fileChooserParams.createIntent();
        } catch (Exception e) {
            intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("*/*");
            intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        }

        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        intent.addFlags(Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);

        try {
            startActivityForResult(intent, FILE_CHOOSER_REQUEST_CODE);
            return true;
        } catch (Exception e) {
            if (filePathCallback != null) {
                filePathCallback.onReceiveValue(null);
            }
            filePathCallback = null;
            Toast.makeText(MainActivity.this, "Tidak bisa membuka pemilih file di HP ini", Toast.LENGTH_SHORT).show();
            return false;
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == MIC_PERMISSION_REQUEST_CODE) {
            PermissionRequest req = pendingMicRequest;
            pendingMicRequest = null;
            if (req != null) {
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    resetAudioModeForMic();
                    req.grant(new String[]{PermissionRequest.RESOURCE_AUDIO_CAPTURE});
                } else {
                    req.deny();
                    Toast.makeText(this, "Izin mikrofon ditolak, voice note tidak bisa direkam.", Toast.LENGTH_SHORT).show();
                }
            }
            return;
        }
        if (requestCode == NOTIF_PERMISSION_REQUEST_CODE) return;
        if (requestCode != MEDIA_PERMISSION_REQUEST_CODE) return;

        WebChromeClient.FileChooserParams params = pendingFileChooserParams;
        pendingFileChooserParams = null;

        boolean granted = grantResults.length > 0;
        for (int result : grantResults) {
            if (result != PackageManager.PERMISSION_GRANTED) { granted = false; break; }
        }

        if (granted && params != null) {
            launchFileChooser(params);
        } else {
            if (filePathCallback != null) {
                filePathCallback.onReceiveValue(null);
                filePathCallback = null;
            }
            Toast.makeText(this, "Izin akses file ditolak, tidak bisa pilih file.", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode != FILE_CHOOSER_REQUEST_CODE || filePathCallback == null) {
            return;
        }

        Uri[] results = null;
        if (resultCode == RESULT_OK && data != null) {
            ClipData clipData = data.getClipData();
            if (clipData != null && clipData.getItemCount() > 0) {
                int count = clipData.getItemCount();
                results = new Uri[count];
                for (int i = 0; i < count; i++) {
                    results[i] = clipData.getItemAt(i).getUri();
                }
            } else if (data.getData() != null) {
                results = new Uri[]{data.getData()};
            } else {
                results = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
            }
        }

        filePathCallback.onReceiveValue(results);
        filePathCallback = null;
    }

    private class StarsWebViewClient extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, android.webkit.WebResourceRequest request) {
            String url = request.getUrl().toString();
            return handleUrl(view, url);
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            return handleUrl(view, url);
        }

        private boolean handleUrl(WebView view, String url) {
            if (url == null) return false;

            // STAR ARENA diarahkan keluar APK ke jalur web khusus.
            if (url.startsWith(starArenaUrl) || url.contains("star-arena")) {
                openExternal(url);
                return true;
            }

            // Link download APK atau file eksternal dibuka lewat browser/download manager.
            if (url.endsWith(".apk") || url.contains("/download") || url.contains("apk")) {
                openExternal(url);
                return true;
            }

            // Link tel/mail/whatsapp/telegram dibuka lewat aplikasi terkait.
            if (
                url.startsWith("tel:") ||
                url.startsWith("mailto:") ||
                url.startsWith("whatsapp:") ||
                url.startsWith("tg:") ||
                url.startsWith("https://t.me/")
            ) {
                openExternal(url);
                return true;
            }

            return false;
        }
    }

    private class StarsDownloadListener implements DownloadListener {
        @Override
        public void onDownloadStart(String url, String userAgent, String contentDisposition, String mimetype, long contentLength) {
            try {
                DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
                request.setMimeType(mimetype);
                request.addRequestHeader("User-Agent", userAgent);
                request.setTitle(URLUtil.guessFileName(url, contentDisposition, mimetype));
                request.setDescription("Mengunduh file STARS IDOLA");
                request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, URLUtil.guessFileName(url, contentDisposition, mimetype));

                DownloadManager dm = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
                if (dm != null) {
                    dm.enqueue(request);
                    Toast.makeText(MainActivity.this, "Download dimulai", Toast.LENGTH_SHORT).show();
                } else {
                    openExternal(url);
                }
            } catch (Exception e) {
                openExternal(url);
            }
        }
    }


    /** Dipanggil dari chat-media.js: simpan media yang DITERIMA ke folder perangkat (Pictures/Movies/Music -> "STARS IDOLA"). */
    private class NativeBridge {
        /** "granted" kalau notifikasi aplikasi ini boleh tampil, selain itu "off". */
        @JavascriptInterface
        public String notifPermission() {
            try {
                return NotificationManagerCompat.from(MainActivity.this).areNotificationsEnabled() ? "granted" : "off";
            } catch (Exception e) {
                return "off";
            }
        }

        /** Minta izin notifikasi (Android 13+). Kalau sudah ditolak permanen / Android lama -> buka pengaturan notifikasi aplikasi. */
        @JavascriptInterface
        public void requestNotifPermission() {
            runOnUiThread(() -> {
                try {
                    if (NotificationManagerCompat.from(MainActivity.this).areNotificationsEnabled()) return;
                    SharedPreferences sp = getSharedPreferences("stars_push", MODE_PRIVATE);
                    boolean asked = sp.getBoolean("asked", false);
                    if (Build.VERSION.SDK_INT >= 33
                            && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                            && (!asked || shouldShowRequestPermissionRationale(Manifest.permission.POST_NOTIFICATIONS))) {
                        sp.edit().putBoolean("asked", true).apply();
                        requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIF_PERMISSION_REQUEST_CODE);
                        return;
                    }
                    Intent i = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS);
                    i.putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName());
                    startActivity(i);
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Buka Pengaturan HP > Aplikasi > STARS IDOLA > Notifikasi", Toast.LENGTH_LONG).show();
                }
            });
        }

        /** Token FCM perangkat ini ("" kalau belum tersedia). */
        @JavascriptInterface
        public String getPushToken() {
            try {
                return getSharedPreferences(StarsFirebaseService.PREFS, MODE_PRIVATE).getString(StarsFirebaseService.KEY_TOKEN, "");
            } catch (Exception e) {
                return "";
            }
        }

        /** Diagnosa mic untuk JS: "ok" | "no_permission" | "muted" | "in_call". */
        @JavascriptInterface
        public String micStatus() {
            try {
                if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return "no_permission";
                AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
                if (am != null) {
                    if (am.isMicrophoneMute()) return "muted";
                    int m = am.getMode();
                    if (m == AudioManager.MODE_IN_CALL || m == AudioManager.MODE_IN_COMMUNICATION) return "in_call";
                }
                return "ok";
            } catch (Exception e) {
                return "ok";
            }
        }

        /** Versi jembatan Room Squad (web memeriksa ini sebelum memakai fitur game-di-dalam-APK). */
        @JavascriptInterface
        public int roomBridgeVersion() { return 2; }

        /** Buka game Star Arena di WebView anak DI DALAM APK (sesi dan suara Room Squad tetap hidup). */
        @JavascriptInterface
        public boolean openGame(final String url, final String title) {
            if (url == null || !(url.startsWith("https://") || url.startsWith("http://"))) return false;
            runOnUiThread(() -> showGameLayer(url, title == null ? "Game" : title));
            return true;
        }

        @JavascriptInterface
        public void gameReply(final String json) {
            runOnUiThread(() -> replyToGame(json));
        }

        @JavascriptInterface
        public void closeGame() {
            runOnUiThread(() -> hideGameLayer());
        }

        /** Status Room Squad dari web, dipakai untuk menggambar bubble native saat game terbuka. */
        @JavascriptInterface
        public void roomState(final boolean joined, final boolean muted, final boolean talking, final int count) {
            runOnUiThread(() -> {
                roomJoined = joined; roomMuted = muted; roomTalking = talking; roomCount = count;
                updateBubble();
            });
        }

        @JavascriptInterface
        public boolean saveMedia(String base64, String mime, String kind, String fileName) {
            try {
                byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
                boolean image = "image".equals(kind), video = "video".equals(kind);
                String dirType = image ? Environment.DIRECTORY_PICTURES : (video ? Environment.DIRECTORY_MOVIES : Environment.DIRECTORY_MUSIC);
                if (Build.VERSION.SDK_INT >= 29) {
                    ContentValues v = new ContentValues();
                    v.put(MediaStore.MediaColumns.DISPLAY_NAME, fileName);
                    v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
                    v.put(MediaStore.MediaColumns.RELATIVE_PATH, dirType + "/STARS IDOLA");
                    Uri collection = image ? MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                            : (video ? MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                            : MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY));
                    Uri uri = getContentResolver().insert(collection, v);
                    if (uri == null) return false;
                    try (OutputStream os = getContentResolver().openOutputStream(uri)) {
                        if (os == null) return false;
                        os.write(bytes);
                    }
                    return true;
                }
                if (checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) return false;
                File dir = new File(Environment.getExternalStoragePublicDirectory(dirType), "STARS IDOLA");
                if (!dir.exists() && !dir.mkdirs()) return false;
                File f = new File(dir, fileName);
                try (FileOutputStream fos = new FileOutputStream(f)) { fos.write(bytes); }
                MediaScannerConnection.scanFile(MainActivity.this, new String[]{f.getAbsolutePath()}, new String[]{mime}, null);
                return true;
            } catch (Exception e) {
                return false;
            }
        }
    }

    // ===================== Room Squad: lapisan game di dalam APK =====================
    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    private void sendToWeb(String ev) {
        try {
            webView.evaluateJavascript("window.__starsRoomNative&&window.__starsRoomNative('" + ev + "')", null);
        } catch (Exception ignored) {}
    }

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    private void showGameLayer(String url, String title) {
        hideGameLayer();
        gameCurrentUrl = url;
        gameLayer = new FrameLayout(this);
        gameLayer.setBackgroundColor(Color.BLACK);
        gameLayer.setClickable(true); // tahan sentuhan agar tidak tembus ke WebView utama
        gameLayer.setOnApplyWindowInsetsListener((v, insets) -> {
            v.setPadding(0, insets.getSystemWindowInsetTop(), 0, insets.getSystemWindowInsetBottom());
            return insets;
        });

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setBackgroundColor(Color.rgb(7, 10, 18));
        bar.setPadding(dp(12), 0, dp(6), 0);

        gameTitleView = new TextView(this);
        gameTitleView.setText(title);
        gameTitleView.setTextColor(Color.rgb(255, 217, 102));
        gameTitleView.setTextSize(13);
        gameTitleView.setTypeface(Typeface.DEFAULT_BOLD);
        gameTitleView.setSingleLine(true);
        gameTitleView.setEllipsize(android.text.TextUtils.TruncateAt.END);
        bar.addView(gameTitleView, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView ext = barButton("\u2197");
        ext.setOnClickListener(v -> openExternal(gameCurrentUrl));
        bar.addView(ext, new LinearLayout.LayoutParams(dp(44), dp(44)));
        TextView close = barButton("\u2715");
        close.setOnClickListener(v -> { hideGameLayer(); sendToWeb("closed"); });
        bar.addView(close, new LinearLayout.LayoutParams(dp(44), dp(44)));
        col.addView(bar, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44)));

        gameWebView = new WebView(this);
        gameWebView.setBackgroundColor(Color.BLACK);
        WebSettings gs = gameWebView.getSettings();
        gs.setJavaScriptEnabled(true);
        gs.setDomStorageEnabled(true);
        gs.setDatabaseEnabled(true);
        gs.setLoadWithOverviewMode(true);
        gs.setUseWideViewPort(true);
        gs.setMediaPlaybackRequiresUserGesture(false);
        gs.setSupportMultipleWindows(false);
        gs.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        CookieManager.getInstance().setAcceptThirdPartyCookies(gameWebView, true);
        gameWebView.addJavascriptInterface(new GameBridge(), "StarsGame");
        gameWebView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(PermissionRequest request) {
                // Game pihak ketiga tidak boleh memakai mikrofon; mikrofon hanya milik Room Squad.
                request.deny();
            }
        });
        gameWebView.setWebViewClient(new StarsGameClient());
        col.addView(gameWebView, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        gameLayer.addView(col, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        rootLayout.addView(gameLayer, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        ensureBubble();
        gameWebView.loadUrl(url);
    }

    private TextView barButton(String label) {
        TextView t = new TextView(this);
        t.setText(label);
        t.setTextColor(Color.WHITE);
        t.setTextSize(17);
        t.setGravity(Gravity.CENTER);
        return t;
    }

    private void hideGameLayer() {
        if (bubbleView != null && bubbleView.getParent() != null) {
            ((ViewGroup) bubbleView.getParent()).removeView(bubbleView);
        }
        if (gameWebView != null) {
            try {
                gameWebView.stopLoading();
                gameWebView.loadUrl("about:blank");
                ViewGroup p = (ViewGroup) gameWebView.getParent();
                if (p != null) p.removeView(gameWebView);
                gameWebView.destroy();
            } catch (Exception ignored) {}
            gameWebView = null;
        }
        if (gameLayer != null) {
            rootLayout.removeView(gameLayer);
            gameLayer = null;
        }
    }

    /** Jalur game: http/https tetap di dalam WebView anak; skema lain (tel, intent, market, dll.) dibuka lewat aplikasi terkait. */
    private class StarsGameClient extends WebViewClient {
        private static final String SHIM =
            "(function(){try{if(window.__starsOpenerShim)return;window.__starsOpenerShim=1;"
          + "var o={closed:false,postMessage:function(m){try{StarsGame.post(JSON.stringify(m))}catch(e){}}};"
          + "Object.defineProperty(window,'opener',{configurable:true,get:function(){return o},set:function(v){}});}catch(e){}})();";

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, android.webkit.WebResourceRequest request) {
            return handle(request.getUrl().toString());
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            return handle(url);
        }

        private boolean handle(String url) {
            if (url == null) return false;
            if (url.startsWith("http://") || url.startsWith("https://") || url.startsWith("about:") || url.startsWith("blob:") || url.startsWith("data:")) return false;
            openExternal(url);
            return true;
        }

        @Override
        public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
            super.onPageStarted(view, url, favicon);
            if (url != null) gameCurrentUrl = url;
            view.evaluateJavascript(SHIM, null);
        }

        @Override
        public void onPageFinished(WebView view, String url) {
            super.onPageFinished(view, url);
            view.evaluateJavascript(SHIM, null);
        }

        @Override
        public void onReceivedError(WebView view, android.webkit.WebResourceRequest request, android.webkit.WebResourceError error) {
            if (request != null && request.isForMainFrame()) {
                Toast.makeText(MainActivity.this, "Game tidak bisa dimuat. Coba tombol \u2197 untuk membuka di browser.", Toast.LENGTH_LONG).show();
            }
        }
    }

    /**
     * Pengganti window.opener untuk game di WebView anak: pesan toko in-game ("stars_shop_purchase") diteruskan ke
     * halaman utama (yang memegang sesi pemain), balasannya dikembalikan ke game. Game tidak pernah memegang kredensial.
     */
    private class GameBridge {
        @JavascriptInterface
        public void post(final String json) {
            if (json == null || json.length() > 4096 || !json.contains("\"stars_")) return;
            runOnUiThread(() -> {
                try {
                    webView.evaluateJavascript("window.__starsGameMsg&&window.__starsGameMsg(" + org.json.JSONObject.quote(json) + ")", null);
                } catch (Exception ignored) {}
            });
        }
    }

    /** Balasan dari halaman utama ke game (dipanggil dari JS lewat StarsIdolaNative.gameReply). */
    private void replyToGame(String json) {
        if (gameWebView == null || json == null || json.length() > 8192) return;
        try {
            gameWebView.evaluateJavascript("window.postMessage(JSON.parse(" + org.json.JSONObject.quote(json) + "),'*')", null);
        } catch (Exception ignored) {}
    }

    // ===================== Bubble native =====================
    private void ensureBubble() {
        if (bubbleView == null) {
            int size = dp(54);
            bubbleView = new FrameLayout(this);
            bubbleBg = new GradientDrawable();
            bubbleBg.setShape(GradientDrawable.OVAL);
            bubbleBg.setColor(Color.rgb(16, 20, 36));
            bubbleView.setBackground(bubbleBg);
            bubbleView.setElevation(dp(8));

            bubbleIcon = new TextView(this);
            bubbleIcon.setText("\uD83C\uDF99\uFE0F");
            bubbleIcon.setTextSize(22);
            bubbleIcon.setGravity(Gravity.CENTER);
            bubbleView.addView(bubbleIcon, new FrameLayout.LayoutParams(size, size));

            bubbleBadge = new TextView(this);
            bubbleBadge.setTextColor(Color.rgb(8, 8, 8));
            bubbleBadge.setTextSize(10);
            bubbleBadge.setTypeface(Typeface.DEFAULT_BOLD);
            bubbleBadge.setGravity(Gravity.CENTER);
            GradientDrawable bb = new GradientDrawable();
            bb.setShape(GradientDrawable.OVAL);
            bb.setColor(Color.rgb(255, 217, 102));
            bubbleBadge.setBackground(bb);
            FrameLayout.LayoutParams blp = new FrameLayout.LayoutParams(dp(18), dp(18), Gravity.TOP | Gravity.END);
            bubbleView.addView(bubbleBadge, blp);

            bubbleView.setOnTouchListener((v, e) -> onBubbleTouch(v, e));
        }
        if (bubbleView.getParent() != null) ((ViewGroup) bubbleView.getParent()).removeView(bubbleView);
        int size = dp(54);
        rootLayout.addView(bubbleView, new FrameLayout.LayoutParams(size, size));
        bubbleView.bringToFront();
        bubbleView.post(() -> {
            SharedPreferences sp = getSharedPreferences(BUBBLE_PREFS, MODE_PRIVATE);
            float fx = sp.getFloat("x", 1f), fy = sp.getFloat("y", 0.62f);
            placeBubble(fx * rootLayout.getWidth(), fy * rootLayout.getHeight(), true);
        });
        updateBubble();
    }

    private void placeBubble(float x, float y, boolean snap) {
        if (bubbleView == null) return;
        int size = dp(54), m = dp(8);
        float maxX = Math.max(m, rootLayout.getWidth() - size - m);
        float maxY = Math.max(dp(56), rootLayout.getHeight() - size - dp(24));
        x = Math.min(Math.max(m, x), maxX);
        y = Math.min(Math.max(dp(56), y), maxY);
        if (snap) x = (x + size / 2f < rootLayout.getWidth() / 2f) ? m : maxX;
        bubbleView.setX(x);
        bubbleView.setY(y);
    }

    private void updateBubble() {
        if (bubbleView == null || bubbleView.getParent() == null) return;
        bubbleView.setVisibility(roomJoined ? View.VISIBLE : View.GONE);
        bubbleIcon.setText(roomMuted ? "\uD83D\uDD07" : "\uD83C\uDF99\uFE0F");
        bubbleBadge.setText(roomCount > 0 ? String.valueOf(roomCount) : "");
        bubbleBadge.setVisibility(roomCount > 0 ? View.VISIBLE : View.GONE);
        int stroke = roomMuted ? Color.rgb(255, 93, 93) : (roomTalking ? Color.rgb(61, 220, 132) : Color.rgb(255, 217, 102));
        bubbleBg.setStroke(dp(2), stroke);
    }

    /** Ketuk 1x = mute/unmute · ketuk 2x = kembali ke modul Squad · tahan lama = geser (menempel ke tepi). */
    private boolean onBubbleTouch(View v, MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                bubbleMoved = false; bubbleDragging = false;
                bubbleDownX = e.getRawX(); bubbleDownY = e.getRawY();
                bubbleStartX = v.getX(); bubbleStartY = v.getY();
                bubbleLongPress = () -> {
                    bubbleDragging = true;
                    v.animate().scaleX(1.15f).scaleY(1.15f).setDuration(120).start();
                    v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
                };
                ui.postDelayed(bubbleLongPress, 450);
                return true;
            case MotionEvent.ACTION_MOVE: {
                float dx = e.getRawX() - bubbleDownX, dy = e.getRawY() - bubbleDownY;
                if (!bubbleDragging) {
                    if (Math.abs(dx) + Math.abs(dy) > dp(10)) { bubbleMoved = true; ui.removeCallbacks(bubbleLongPress); }
                    return true;
                }
                placeBubble(bubbleStartX + dx, bubbleStartY + dy, false);
                bubbleMoved = true;
                return true;
            }
            case MotionEvent.ACTION_UP:
                ui.removeCallbacks(bubbleLongPress);
                if (bubbleDragging) {
                    bubbleDragging = false;
                    v.animate().scaleX(1f).scaleY(1f).setDuration(120).start();
                    placeBubble(v.getX(), v.getY(), true);
                    getSharedPreferences(BUBBLE_PREFS, MODE_PRIVATE).edit()
                        .putFloat("x", v.getX() / Math.max(1, rootLayout.getWidth()))
                        .putFloat("y", v.getY() / Math.max(1, rootLayout.getHeight())).apply();
                    return true;
                }
                if (bubbleMoved) return true;
                long now = SystemClock.uptimeMillis();
                if (now - bubbleLastTap < 280) {
                    ui.removeCallbacks(bubblePendingSingle);
                    bubbleLastTap = 0;
                    hideGameLayer();
                    sendToWeb("back");
                } else {
                    bubbleLastTap = now;
                    bubblePendingSingle = () -> { bubbleLastTap = 0; sendToWeb("mute"); };
                    ui.postDelayed(bubblePendingSingle, 285);
                }
                return true;
            case MotionEvent.ACTION_CANCEL:
                ui.removeCallbacks(bubbleLongPress);
                bubbleDragging = false;
                v.animate().scaleX(1f).scaleY(1f).setDuration(100).start();
                return true;
            default:
                return false;
        }
    }

    private void openExternal(String url) {
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this, "Tidak bisa membuka link", Toast.LENGTH_SHORT).show();
        }
    }

    private boolean isOnline() {
        try {
            ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo info = cm != null ? cm.getActiveNetworkInfo() : null;
            return info != null && info.isConnected();
        } catch (Exception e) {
            return true;
        }
    }

    @Override
    public void onBackPressed() {
        if (gameLayer != null) {
            if (gameWebView != null && gameWebView.canGoBack()) {
                gameWebView.goBack();
            } else {
                hideGameLayer();
                sendToWeb("closed");
            }
            return;
        }
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        try { hideGameLayer(); } catch (Exception ignored) {}
        super.onDestroy();
    }
}
