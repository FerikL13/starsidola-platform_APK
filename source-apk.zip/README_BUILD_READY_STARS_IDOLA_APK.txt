STARS IDOLA GLOBAL APK - BUILD READY
====================================

Status paket:
- Sudah berisi Android WebView project.
- Sudah terpasang icon APK STARS IDOLA.
- Nama aplikasi: STARS IDOLA.
- Global URL sudah diarahkan ke:
  https://platform.starsidola.workers.dev

- STAR ARENA URL disiapkan:
  https://star-arena.starsidola.workers.dev

Cara upload ke GitHub:
1. Buat repository baru, misalnya:
   stars-idola-global-apk

2. Upload semua isi folder ini ke repo tersebut.
   Jangan upload ZIP-nya sebagai satu file saja.
   Yang di-upload harus folder/file di dalamnya:
   .github/
   app/
   build.gradle
   settings.gradle
   README...

3. Buka tab Actions di GitHub.
4. Jalankan workflow:
   Build STARS IDOLA Global APK

5. Setelah selesai, buka artifact:
   stars-idola-global-debug-apk

6. Download hasil:
   app-debug.apk

Catatan:
- app-debug.apk adalah APK test awal.
- Untuk rilis resmi nanti perlu signed release APK/AAB.
- Isi platform tetap dari Global Web, jadi update fitur cukup deploy Global.
- APK baru dibutuhkan kalau icon, nama app, izin Android, package name, atau WebView setting berubah.

Penting:
- Setelah APK jadi, upload APK ke tempat download resmi.
- Lalu masukkan URL APK ke Firebase:
  appConfig/downloads/globalApk

Contoh isi Firebase:
{
  "appName": "STARS IDOLA Global",
  "versionName": "1.0.0",
  "versionCode": 1,
  "apkUrl": "https://link-download-apk-kamu/app-debug.apk",
  "active": true,
  "releaseNotes": "Versi awal STARS IDOLA Global APK.",
  "updatedAt": 0
}
