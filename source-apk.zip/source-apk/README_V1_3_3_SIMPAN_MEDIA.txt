STARS IDOLA APK v1.3.3 (versionCode 8)

Perubahan: jembatan simpan media.
- Baru: StarsIdolaNative.saveMediaTo(base64, mime, folder, fileName) -> true bila file benar-benar tertulis.
- Semua media chat (Inbox, Squad, chat order Agen P2P) disimpan ke:
    Documents/STARS IDOLA/Foto | Video | Suara | Bukti P2P
  Folder Documents/STARS IDOLA diberi file .nomedia supaya tidak tampil di galeri,
  tetap bisa dibuka lewat file manager, dan tidak ikut terhapus saat APK di-uninstall.
- saveMedia (nama lama) sekarang juga menyimpan ke Documents/STARS IDOLA (tidak lagi ke galeri).
- Android 11+: tulis langsung ke Documents (tanpa izin tambahan), cadangan lewat MediaStore.
  Android 10: lewat MediaStore. Android 6-9: butuh izin penyimpanan (diminta saat aplikasi dibuka).
- Web memakai hasil true/false: bukti P2P dihapus dari server HANYA bila tersimpan di folder HP.
